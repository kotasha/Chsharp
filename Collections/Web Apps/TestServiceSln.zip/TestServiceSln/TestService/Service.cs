using System;
using System.Collections.Generic;
using System.Text;

namespace TestService
{
	public class Service:IService 
	{
		#region IService Members

		public string TestCall()
		{
			return "You just called a WCF webservice On SSL(Transport Layer Security)";
		}

		#endregion
	}
}
