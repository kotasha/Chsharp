using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
namespace TestService
{	
	[ServiceContract]
	interface IService
	{
		[OperationContract]
		string TestCall();

	}
}
